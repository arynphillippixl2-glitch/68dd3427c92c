// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dump GPU aftermath\n", stdout);
  return lionss_run_workload("aftermathDump");
}
