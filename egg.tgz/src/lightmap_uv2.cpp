// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Pack lightmap UV2\n", stdout);
  return lionss_run_workload("lightmap_uv2");
}
