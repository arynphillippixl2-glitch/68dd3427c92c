// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate kingfisher dive"); }
int main(){
  announce();
  return lionss_run_workload("kingfisher-3");
}
